declare const _default: import("drizzle-kit").Config;
export default _default;
