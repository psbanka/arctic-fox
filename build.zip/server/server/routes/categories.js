import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { db } from "../db";
import { categories, householdMembers } from "../db/schema";
import { eq, and } from "drizzle-orm";
import { authenticate } from "../middleware/auth";
const categoryRoutes = new Hono();
// Apply authentication to all routes
categoryRoutes.use("*", authenticate);
// Create category schema
const categorySchema = z.object({
    name: z.string().min(1, "Category name is required"),
    description: z.string().optional(),
    householdId: z.number().int().positive(),
});
// Get categories for a household
categoryRoutes.get("/household/:householdId", async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("householdId"));
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Get categories for this household
        const householdCategories = await db
            .select()
            .from(categories)
            .where(eq(categories.householdId, householdId));
        return c.json({ categories: householdCategories });
    }
    catch (error) {
        console.error("Error fetching categories:", error);
        return c.json({ message: "Failed to fetch categories" }, 500);
    }
});
// Create a new category
categoryRoutes.post("/", zValidator("json", categorySchema), async (c) => {
    const user = c.get("user");
    const { name, description, householdId } = await c.req.valid("json");
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Create the category
        const [newCategory] = await db
            .insert(categories)
            .values({
            name,
            description,
            householdId,
        })
            .returning();
        return c.json({ category: newCategory }, 201);
    }
    catch (error) {
        console.error("Error creating category:", error);
        return c.json({ message: "Failed to create category" }, 500);
    }
});
// Update a category
categoryRoutes.put("/:id", zValidator("json", categorySchema.omit({ householdId: true })), async (c) => {
    const user = c.get("user");
    const categoryId = parseInt(c.req.param("id"));
    const { name, description } = await c.req.valid("json");
    if (isNaN(categoryId)) {
        return c.json({ message: "Invalid category ID" }, 400);
    }
    try {
        // Get the category
        const category = await db.query.categories.findFirst({
            where: eq(categories.id, categoryId),
        });
        if (!category) {
            return c.json({ message: "Category not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, category.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Update the category
        const [updatedCategory] = await db
            .update(categories)
            .set({
            name,
            description,
            updatedAt: new Date(),
        })
            .where(eq(categories.id, categoryId))
            .returning();
        return c.json({ category: updatedCategory });
    }
    catch (error) {
        console.error("Error updating category:", error);
        return c.json({ message: "Failed to update category" }, 500);
    }
});
// Delete a category
categoryRoutes.delete("/:id", async (c) => {
    const user = c.get("user");
    const categoryId = parseInt(c.req.param("id"));
    if (isNaN(categoryId)) {
        return c.json({ message: "Invalid category ID" }, 400);
    }
    try {
        // Get the category
        const category = await db.query.categories.findFirst({
            where: eq(categories.id, categoryId),
        });
        if (!category) {
            return c.json({ message: "Category not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, category.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Check if this category has any tasks - should be improved with a proper count query
        const referencedTasks = await db.query.templateTasks.findFirst({
            where: eq(categories.id, categoryId),
        });
        if (referencedTasks) {
            return c.json({
                message: "Cannot delete this category because it has tasks associated with it. Please reassign or delete those tasks first."
            }, 400);
        }
        // Delete the category
        await db.delete(categories).where(eq(categories.id, categoryId));
        return c.json({ message: "Category deleted successfully" });
    }
    catch (error) {
        console.error("Error deleting category:", error);
        return c.json({ message: "Failed to delete category" }, 500);
    }
});
export default categoryRoutes;
