import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "../db";
import { users } from "../db/schema";
import { mapUserModelToUser } from "../db/types";
import { generateToken, comparePassword, hashPassword } from "../utils/auth";
import { authenticate, requireAdmin } from "../middleware/auth";
const authRoutes = new Hono();
// Login schema
const loginSchema = z.object({
    username: z.string().min(1, "Username is required"),
    password: z.string().min(1, "Password is required"),
});
// Create user schema - use the CreateUserRequest type for validation
const createUserSchema = z.object({
    username: z.string().min(3, "Username must be at least 3 characters"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    isAdmin: z.boolean().optional().default(false),
});
// Login endpoint
authRoutes.post("/login", zValidator("json", loginSchema), async (c) => {
    const { username, password } = await c.req.valid("json");
    try {
        // Find user by username
        const userModel = await db.query.users.findFirst({
            where: eq(users.username, username),
        });
        if (!userModel) {
            return c.json({ message: "Invalid username or password" }, 401);
        }
        // Verify password
        const isPasswordValid = await comparePassword(password, userModel.passwordHash);
        if (!isPasswordValid) {
            return c.json({ message: "Invalid username or password" }, 401);
        }
        // Convert database model to API type
        const user = mapUserModelToUser(userModel);
        // Generate JWT
        const token = generateToken({
            id: user.id,
            username: user.username,
            firstName: user.firstName,
            lastName: user.lastName,
            isAdmin: user.isAdmin,
        });
        // Create response with shared type
        const response = {
            token,
            user,
        };
        return c.json(response);
    }
    catch (error) {
        console.error("Login error:", error);
        return c.json({ message: "Login failed" }, 500);
    }
});
// Current user endpoint
authRoutes.get("/me", authenticate, async (c) => {
    const user = c.get("user");
    return c.json({ user });
});
// Admin-only: Create user
authRoutes.post("/users", authenticate, requireAdmin, zValidator("json", createUserSchema), async (c) => {
    const userData = await c.req.valid("json");
    try {
        // Check if username already exists
        const existingUser = await db.query.users.findFirst({
            where: eq(users.username, userData.username),
        });
        if (existingUser) {
            return c.json({ message: "Username already exists" }, 400);
        }
        // Hash password
        const passwordHash = await hashPassword(userData.password);
        // Store new user in the database
        const [newUserModel] = await db
            .insert(users)
            .values({
            username: userData.username,
            passwordHash,
            firstName: userData.firstName,
            lastName: userData.lastName,
            isAdmin: userData.isAdmin || false,
            createdAt: new Date(),
            updatedAt: new Date()
        })
            .returning({
            id: users.id,
            username: users.username,
            passwordHash: users.passwordHash,
            firstName: users.firstName,
            lastName: users.lastName,
            isAdmin: users.isAdmin,
            createdAt: users.createdAt,
            updatedAt: users.updatedAt
        });
        // Convert to API type
        const newUser = mapUserModelToUser(newUserModel);
        return c.json({ user: newUser }, 201);
    }
    catch (error) {
        console.error("User creation error:", error);
        return c.json({ message: "Failed to create user" }, 500);
    }
});
// Admin-only: Get all users
authRoutes.get("/users", authenticate, requireAdmin, async (c) => {
    try {
        const userModelsList = await db.select({
            id: users.id,
            username: users.username,
            firstName: users.firstName,
            lastName: users.lastName,
            isAdmin: users.isAdmin,
            createdAt: users.createdAt,
        }).from(users);
        // Convert to API types
        const usersList = userModelsList.map(mapUserModelToUser);
        return c.json({ users: usersList });
    }
    catch (error) {
        console.error("Error fetching users:", error);
        return c.json({ message: "Failed to fetch users" }, 500);
    }
});
export default authRoutes;
