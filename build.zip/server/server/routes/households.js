import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { db } from "../db";
import { households, householdMembers, users } from "../db/schema";
import { authenticate } from "../middleware/auth";
const householdRoutes = new Hono();
// Apply authentication to all routes
householdRoutes.use("*", authenticate);
// Create household schema
const createHouseholdSchema = z.object({
    name: z.string().min(1, "Household name is required"),
});
// Add member schema
const addMemberSchema = z.object({
    userId: z.number().int().positive(),
    isOwner: z.boolean().optional().default(false),
});
// Get user's households
householdRoutes.get("/", async (c) => {
    const user = c.get("user");
    try {
        // Get all households this user is a member of
        const householdsData = await db
            .select({
            id: households.id,
            name: households.name,
            createdAt: households.createdAt,
            updatedAt: households.updatedAt,
            isOwner: householdMembers.isOwner,
        })
            .from(households)
            .innerJoin(householdMembers, and(eq(households.id, householdMembers.householdId), eq(householdMembers.userId, user.id)));
        // Convert Date objects to ISO strings to match the Household type
        const userHouseholds = householdsData.map(household => ({
            id: household.id,
            name: household.name,
            createdAt: household.createdAt.toISOString(),
            updatedAt: household.updatedAt.toISOString(),
            isOwner: household.isOwner
        }));
        return c.json(userHouseholds);
    }
    catch (error) {
        console.error("Error fetching households:", error);
        return c.json({ message: "Failed to fetch households" }, 500);
    }
});
// Create a new household
householdRoutes.post("/", zValidator("json", createHouseholdSchema), async (c) => {
    const user = c.get("user");
    const { name } = await c.req.valid("json");
    try {
        // Create the household
        const householdData = {
            name,
        };
        const [newHousehold] = await db
            .insert(households)
            .values(householdData)
            .returning();
        // Add the current user as an owner
        const memberData = {
            userId: user.id,
            householdId: newHousehold.id,
            isOwner: true,
        };
        await db.insert(householdMembers).values(memberData);
        return c.json({ household: newHousehold }, 201);
    }
    catch (error) {
        console.error("Error creating household:", error);
        return c.json({ message: "Failed to create household" }, 500);
    }
});
// Get a specific household by ID
householdRoutes.get("/:id", async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("id"));
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Get household details
        const householdResult = await db
            .select({
            id: households.id,
            name: households.name,
            createdAt: households.createdAt,
            updatedAt: households.updatedAt,
        })
            .from(households)
            .where(eq(households.id, householdId))
            .limit(1);
        if (householdResult.length === 0) {
            return c.json({ message: "Household not found" }, 404);
        }
        // Check if user is a member of this household
        const membershipResult = await db
            .select({
            isOwner: householdMembers.isOwner,
        })
            .from(householdMembers)
            .where(and(eq(householdMembers.householdId, householdId), eq(householdMembers.userId, user.id)))
            .limit(1);
        if (membershipResult.length === 0) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Get all members of this household
        const membersData = await db
            .select({
            id: users.id,
            username: users.username,
            firstName: users.firstName,
            lastName: users.lastName,
            isOwner: householdMembers.isOwner,
        })
            .from(users)
            .innerJoin(householdMembers, and(eq(householdMembers.userId, users.id), eq(householdMembers.householdId, householdId)));
        // Map to HouseholdMember type
        const members = membersData.map(member => ({
            id: member.id,
            username: member.username,
            firstName: member.firstName,
            lastName: member.lastName,
            isOwner: member.isOwner
        }));
        // Create the household detail object
        const householdDetail = {
            id: householdResult[0].id,
            name: householdResult[0].name,
            createdAt: householdResult[0].createdAt.toISOString(),
            updatedAt: householdResult[0].updatedAt.toISOString(),
            isOwner: membershipResult[0].isOwner,
            members
        };
        return c.json(householdDetail);
    }
    catch (error) {
        console.error("Error fetching household:", error);
        return c.json({ message: "Failed to fetch household details" }, 500);
    }
});
// Add a member to a household
householdRoutes.post("/:id/members", zValidator("json", addMemberSchema), async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("id"));
    const { userId, isOwner } = await c.req.valid("json");
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Check if the current user is an owner of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership || !membership.isOwner) {
            return c.json({ message: "Only household owners can add members" }, 403);
        }
        // Check if the user to be added exists
        const userToAdd = await db.query.users.findFirst({
            where: eq(users.id, userId),
        });
        if (!userToAdd) {
            return c.json({ message: "User not found" }, 404);
        }
        // Check if the user is already a member
        const existingMembership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, userId), eq(householdMembers.householdId, householdId)),
        });
        if (existingMembership) {
            return c.json({ message: "User is already a member of this household" }, 400);
        }
        // Create member data with proper typing
        const memberData = {
            userId,
            householdId,
            isOwner,
        };
        // Add the user to the household
        await db.insert(householdMembers).values(memberData);
        return c.json({
            message: "Member added successfully",
            member: {
                id: userToAdd.id,
                username: userToAdd.username,
                firstName: userToAdd.firstName,
                lastName: userToAdd.lastName,
                isOwner,
            },
        });
    }
    catch (error) {
        console.error("Error adding member:", error);
        return c.json({ message: "Failed to add member to household" }, 500);
    }
});
// Update household name
householdRoutes.put("/:id", zValidator("json", createHouseholdSchema), async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("id"));
    const { name } = await c.req.valid("json");
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Check if the current user is an owner of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership || !membership.isOwner) {
            return c.json({ message: "Only household owners can update the household" }, 403);
        }
        // Update the household
        const [updatedHousehold] = await db
            .update(households)
            .set({
            name,
            updatedAt: new Date(),
        })
            .where(eq(households.id, householdId))
            .returning();
        return c.json({ household: updatedHousehold });
    }
    catch (error) {
        console.error("Error updating household:", error);
        return c.json({ message: "Failed to update household" }, 500);
    }
});
// Remove a member from a household
householdRoutes.delete("/:householdId/members/:userId", async (c) => {
    const currentUser = c.get("user");
    const householdId = parseInt(c.req.param("householdId"));
    const userIdToRemove = parseInt(c.req.param("userId"));
    if (isNaN(householdId) || isNaN(userIdToRemove)) {
        return c.json({ message: "Invalid household ID or user ID" }, 400);
    }
    try {
        // Check if the current user is an owner of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, currentUser.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Allow users to remove themselves, or owners to remove anyone
        if (currentUser.id !== userIdToRemove && !membership.isOwner) {
            return c.json({ message: "Only household owners can remove other members" }, 403);
        }
        // Make sure we're not removing the last owner
        if (membership.isOwner && currentUser.id === userIdToRemove) {
            // Count other owners
            const otherOwners = await db
                .select({ count: householdMembers.userId })
                .from(householdMembers)
                .where(and(eq(householdMembers.householdId, householdId), eq(householdMembers.isOwner, true)));
            // If this is the only owner, prevent removal
            if (otherOwners.length <= 1) {
                return c.json({ message: "Cannot remove the only owner. Promote another member to owner first" }, 400);
            }
        }
        // Remove the member
        await db
            .delete(householdMembers)
            .where(and(eq(householdMembers.userId, userIdToRemove), eq(householdMembers.householdId, householdId)));
        return c.json({ message: "Member removed successfully" });
    }
    catch (error) {
        console.error("Error removing member:", error);
        return c.json({ message: "Failed to remove member from household" }, 500);
    }
});
export default householdRoutes;
