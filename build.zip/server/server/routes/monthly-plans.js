import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { db } from "../db";
import { templates, templateTasks, templateTaskAssignments, monthlyPlans, tasks, taskAssignments, categories, householdMembers, users, } from "../db/schema";
import { eq, and, inArray, desc } from "drizzle-orm";
import { authenticate } from "../middleware/auth";
const monthlyPlanRoutes = new Hono();
// Apply authentication to all routes
monthlyPlanRoutes.use("*", authenticate);
// Create a monthly plan schema
const createMonthlyPlanSchema = z.object({
    householdId: z.number().int().positive(),
    month: z.number().int().min(1).max(12),
    year: z.number().int().min(2000).max(3000),
    name: z.string().min(1, "Plan name is required"),
    templateId: z.number().int().positive().optional(),
});
// Create a task schema
const createTaskSchema = z.object({
    monthlyPlanId: z.number().int().positive(),
    categoryId: z.number().int().positive(),
    name: z.string().min(1, "Task name is required"),
    description: z.string().optional(),
    storyPoints: z.number().int().positive().refine((val) => {
        // Fibonacci sequence check (1, 2, 3, 5, 8, 13, 21, etc.)
        const fibNumbers = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
        return fibNumbers.includes(val);
    }, "Story points must be a Fibonacci number (1, 2, 3, 5, 8, 13, 21, etc.)"),
    isTemplateTask: z.boolean().default(false),
    assignedUserIds: z.array(z.number().int().positive()),
    dueDate: z.string().optional(),
});
// Complete task schema
const completeTaskSchema = z.object({
    isCompleted: z.boolean(),
});
// Get monthly plans for a household
monthlyPlanRoutes.get("/household/:householdId", async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("householdId"));
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Get monthly plans for this household
        const plans = await db
            .select()
            .from(monthlyPlans)
            .where(eq(monthlyPlans.householdId, householdId))
            .orderBy(desc(monthlyPlans.year), desc(monthlyPlans.month));
        return c.json({ plans });
    }
    catch (error) {
        console.error("Error fetching monthly plans:", error);
        return c.json({ message: "Failed to fetch monthly plans" }, 500);
    }
});
// Create a new monthly plan
monthlyPlanRoutes.post("/", zValidator("json", createMonthlyPlanSchema), async (c) => {
    const user = c.get("user");
    const { householdId, month, year, name, templateId } = await c.req.valid("json");
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Check if a plan for this month and year already exists
        const existingPlan = await db.query.monthlyPlans.findFirst({
            where: and(eq(monthlyPlans.householdId, householdId), eq(monthlyPlans.month, month), eq(monthlyPlans.year, year)),
        });
        if (existingPlan) {
            return c.json({ message: "A plan for this month and year already exists" }, 400);
        }
        // Create the monthly plan
        const [newPlan] = await db
            .insert(monthlyPlans)
            .values({
            householdId,
            month,
            year,
            name,
            isClosed: false,
        })
            .returning();
        // If a template ID is provided, generate tasks from it
        if (templateId) {
            // Verify template belongs to this household
            const template = await db.query.templates.findFirst({
                where: and(eq(templates.id, templateId), eq(templates.householdId, householdId)),
            });
            if (!template) {
                return c.json({
                    message: "Template not found or doesn't belong to this household",
                    plan: newPlan
                }, 400);
            }
            // Get template tasks
            const templateTasksList = await db.query.templateTasks.findMany({
                where: eq(templateTasks.templateId, templateId),
            });
            // For each template task
            for (const templateTask of templateTasksList) {
                // Create task instances based on timesPerMonth
                for (let i = 0; i < templateTask.timesPerMonth; i++) {
                    const [newTask] = await db
                        .insert(tasks)
                        .values({
                        monthlyPlanId: newPlan.id,
                        templateTaskId: templateTask.id,
                        categoryId: templateTask.categoryId,
                        name: templateTask.name,
                        description: templateTask.description,
                        storyPoints: templateTask.storyPoints,
                        isTemplateTask: true,
                        isCompleted: false,
                    })
                        .returning();
                    // Handle task assignments
                    if (templateTask.assignToAll) {
                        // Assign to all household members
                        const householdMembersList = await db
                            .select({ userId: householdMembers.userId })
                            .from(householdMembers)
                            .where(eq(householdMembers.householdId, householdId));
                        await db.insert(taskAssignments).values(householdMembersList.map((member) => ({
                            taskId: newTask.id,
                            userId: member.userId,
                        })));
                    }
                    else {
                        // Assign to specific users
                        const assignments = await db
                            .select({ userId: templateTaskAssignments.userId })
                            .from(templateTaskAssignments)
                            .where(eq(templateTaskAssignments.templateTaskId, templateTask.id));
                        if (assignments.length > 0) {
                            await db.insert(taskAssignments).values(assignments.map((assignment) => ({
                                taskId: newTask.id,
                                userId: assignment.userId,
                            })));
                        }
                    }
                }
            }
        }
        return c.json({ plan: newPlan }, 201);
    }
    catch (error) {
        console.error("Error creating monthly plan:", error);
        return c.json({ message: "Failed to create monthly plan" }, 500);
    }
});
// Get a specific monthly plan with its tasks
monthlyPlanRoutes.get("/:id", async (c) => {
    const user = c.get("user");
    const planId = parseInt(c.req.param("id"));
    if (isNaN(planId)) {
        return c.json({ message: "Invalid plan ID" }, 400);
    }
    try {
        // Get the plan
        const plan = await db.query.monthlyPlans.findFirst({
            where: eq(monthlyPlans.id, planId),
        });
        if (!plan) {
            return c.json({ message: "Plan not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, plan.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Get tasks for this plan
        const tasksList = await db
            .select({
            id: tasks.id,
            name: tasks.name,
            description: tasks.description,
            categoryId: tasks.categoryId,
            categoryName: categories.name,
            storyPoints: tasks.storyPoints,
            isTemplateTask: tasks.isTemplateTask,
            isCompleted: tasks.isCompleted,
            completedAt: tasks.completedAt,
            completedBy: tasks.completedBy,
            dueDate: tasks.dueDate,
            createdAt: tasks.createdAt,
            updatedAt: tasks.updatedAt,
        })
            .from(tasks)
            .leftJoin(categories, eq(tasks.categoryId, categories.id))
            .where(eq(tasks.monthlyPlanId, planId));
        // Get task assignments
        const taskIds = tasksList.map((task) => task.id);
        // Only fetch assignments if there are tasks
        let assignmentsByTask = {};
        if (taskIds.length > 0) {
            const assignments = await db
                .select({
                taskId: taskAssignments.taskId,
                userId: users.id,
                firstName: users.firstName,
                lastName: users.lastName,
            })
                .from(taskAssignments)
                .innerJoin(users, eq(taskAssignments.userId, users.id))
                .where(inArray(taskAssignments.taskId, taskIds));
            // Group assignments by task
            assignmentsByTask = assignments.reduce((acc, curr) => {
                if (!acc[curr.taskId]) {
                    acc[curr.taskId] = [];
                }
                acc[curr.taskId].push({
                    userId: curr.userId,
                    firstName: curr.firstName,
                    lastName: curr.lastName,
                });
                return acc;
            }, {});
        }
        // Add assignments to tasks
        const tasksWithAssignments = tasksList.map((task) => ({
            ...task,
            assignedUsers: assignmentsByTask[task.id] || [],
        }));
        // Get household categories for reference
        const householdCategories = await db
            .select()
            .from(categories)
            .where(eq(categories.householdId, plan.householdId));
        // Get household members for reference
        const householdMembersList = await db
            .select({
            id: users.id,
            firstName: users.firstName,
            lastName: users.lastName,
        })
            .from(users)
            .innerJoin(householdMembers, and(eq(householdMembers.userId, users.id), eq(householdMembers.householdId, plan.householdId)));
        // Get statistics for this plan
        const totalTasks = tasksList.length;
        const completedTasks = tasksList.filter((task) => task.isCompleted).length;
        const totalStoryPoints = tasksList.reduce((sum, task) => sum + task.storyPoints, 0);
        const completedStoryPoints = tasksList
            .filter((task) => task.isCompleted)
            .reduce((sum, task) => sum + task.storyPoints, 0);
        // Get statistics by category
        const categoryStats = householdCategories.map((category) => {
            const categoryTasks = tasksList.filter((task) => task.categoryId === category.id);
            const categoryCompletedTasks = categoryTasks.filter((task) => task.isCompleted);
            return {
                categoryId: category.id,
                categoryName: category.name,
                totalTasks: categoryTasks.length,
                completedTasks: categoryCompletedTasks.length,
                totalStoryPoints: categoryTasks.reduce((sum, task) => sum + task.storyPoints, 0),
                completedStoryPoints: categoryCompletedTasks.reduce((sum, task) => sum + task.storyPoints, 0),
            };
        });
        // Get statistics by user
        const userStats = householdMembersList.map((member) => {
            const memberTasks = tasksList.filter((task) => {
                const assignedUsers = assignmentsByTask[task.id] || [];
                return assignedUsers.some((user) => user.userId === member.id);
            });
            const memberCompletedTasks = memberTasks.filter((task) => task.isCompleted);
            return {
                userId: member.id,
                firstName: member.firstName,
                lastName: member.lastName,
                totalTasks: memberTasks.length,
                completedTasks: memberCompletedTasks.length,
                totalStoryPoints: memberTasks.reduce((sum, task) => sum + task.storyPoints, 0),
                completedStoryPoints: memberCompletedTasks.reduce((sum, task) => sum + task.storyPoints, 0),
            };
        });
        // Get the previous month's plan for comparison
        let previousMonthPlan = null;
        let previousMonthStats = null;
        // Calculate the previous month (handling year rollover)
        const prevMonth = plan.month === 1 ? 12 : plan.month - 1;
        const prevYear = plan.month === 1 ? plan.year - 1 : plan.year;
        previousMonthPlan = await db.query.monthlyPlans.findFirst({
            where: and(eq(monthlyPlans.householdId, plan.householdId), eq(monthlyPlans.month, prevMonth), eq(monthlyPlans.year, prevYear)),
        });
        if (previousMonthPlan) {
            // Get previous month's tasks
            const previousTasks = await db
                .select({
                id: tasks.id,
                storyPoints: tasks.storyPoints,
                isCompleted: tasks.isCompleted,
                categoryId: tasks.categoryId,
            })
                .from(tasks)
                .where(eq(tasks.monthlyPlanId, previousMonthPlan.id));
            const prevTotalTasks = previousTasks.length;
            const prevCompletedTasks = previousTasks.filter((task) => task.isCompleted).length;
            const prevTotalStoryPoints = previousTasks.reduce((sum, task) => sum + task.storyPoints, 0);
            const prevCompletedStoryPoints = previousTasks
                .filter((task) => task.isCompleted)
                .reduce((sum, task) => sum + task.storyPoints, 0);
            previousMonthStats = {
                totalTasks: prevTotalTasks,
                completedTasks: prevCompletedTasks,
                totalStoryPoints: prevTotalStoryPoints,
                completedStoryPoints: prevCompletedStoryPoints,
                completionRate: prevTotalTasks > 0 ? (prevCompletedTasks / prevTotalTasks) * 100 : 0,
                storyPointCompletionRate: prevTotalStoryPoints > 0
                    ? (prevCompletedStoryPoints / prevTotalStoryPoints) * 100
                    : 0,
            };
        }
        return c.json({
            plan,
            tasks: tasksWithAssignments,
            categories: householdCategories,
            members: householdMembersList,
            stats: {
                totalTasks,
                completedTasks,
                totalStoryPoints,
                completedStoryPoints,
                completionRate: totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0,
                storyPointCompletionRate: totalStoryPoints > 0
                    ? (completedStoryPoints / totalStoryPoints) * 100
                    : 0,
                categoryStats,
                userStats,
                previousMonth: previousMonthStats,
            },
        });
    }
    catch (error) {
        console.error("Error fetching monthly plan:", error);
        return c.json({ message: "Failed to fetch monthly plan details" }, 500);
    }
});
// Add a task to a monthly plan
monthlyPlanRoutes.post("/tasks", zValidator("json", createTaskSchema), async (c) => {
    const user = c.get("user");
    const { monthlyPlanId, categoryId, name, description, storyPoints, isTemplateTask, assignedUserIds, dueDate, } = await c.req.valid("json");
    try {
        // Get the plan
        const plan = await db.query.monthlyPlans.findFirst({
            where: eq(monthlyPlans.id, monthlyPlanId),
        });
        if (!plan) {
            return c.json({ message: "Plan not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, plan.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Check if the plan is closed
        if (plan.isClosed) {
            return c.json({ message: "Cannot add tasks to a closed plan" }, 400);
        }
        // Verify the category belongs to this household
        const category = await db.query.categories.findFirst({
            where: and(eq(categories.id, categoryId), eq(categories.householdId, plan.householdId)),
        });
        if (!category) {
            return c.json({
                message: "Category not found or doesn't belong to this household"
            }, 400);
        }
        // Create the task
        const [newTask] = await db
            .insert(tasks)
            .values({
            monthlyPlanId,
            categoryId,
            name,
            description,
            storyPoints,
            isTemplateTask,
            isCompleted: false,
            dueDate: dueDate ? new Date(dueDate) : null,
        })
            .returning();
        // Verify all users are household members
        const householdMemberIds = await db
            .select({ userId: householdMembers.userId })
            .from(householdMembers)
            .where(eq(householdMembers.householdId, plan.householdId));
        const validMemberIds = new Set(householdMemberIds.map((m) => m.userId));
        const validAssignees = assignedUserIds.filter((id) => validMemberIds.has(id));
        // Create assignments
        if (validAssignees.length > 0) {
            await db.insert(taskAssignments).values(validAssignees.map((userId) => ({
                taskId: newTask.id,
                userId,
            })));
        }
        return c.json({
            task: {
                ...newTask,
                categoryName: category.name,
            },
        }, 201);
    }
    catch (error) {
        console.error("Error creating task:", error);
        return c.json({ message: "Failed to create task" }, 500);
    }
});
// Complete/uncomplete a task
monthlyPlanRoutes.patch("/tasks/:taskId/complete", zValidator("json", completeTaskSchema), async (c) => {
    const user = c.get("user");
    const taskId = parseInt(c.req.param("taskId"));
    const { isCompleted } = await c.req.valid("json");
    if (isNaN(taskId)) {
        return c.json({ message: "Invalid task ID" }, 400);
    }
    try {
        // Get the task
        const task = await db.query.tasks.findFirst({
            where: eq(tasks.id, taskId),
        });
        if (!task) {
            return c.json({ message: "Task not found" }, 404);
        }
        // Get the plan
        const plan = await db.query.monthlyPlans.findFirst({
            where: eq(monthlyPlans.id, task.monthlyPlanId),
        });
        if (!plan) {
            return c.json({ message: "Plan not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, plan.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Check if the plan is closed
        if (plan.isClosed) {
            return c.json({ message: "Cannot update tasks in a closed plan" }, 400);
        }
        // Check if user is assigned to this task
        const assignment = await db.query.taskAssignments.findFirst({
            where: and(eq(taskAssignments.taskId, taskId), eq(taskAssignments.userId, user.id)),
        });
        if (!assignment) {
            return c.json({ message: "You are not assigned to this task" }, 403);
        }
        // Update the task
        const [updatedTask] = await db
            .update(tasks)
            .set({
            isCompleted,
            completedAt: isCompleted ? new Date() : null,
            completedBy: isCompleted ? user.id : null,
            updatedAt: new Date(),
        })
            .where(eq(tasks.id, taskId))
            .returning();
        return c.json({ task: updatedTask });
    }
    catch (error) {
        console.error("Error updating task:", error);
        return c.json({ message: "Failed to update task" }, 500);
    }
});
// Close a monthly plan
monthlyPlanRoutes.patch("/:id/close", async (c) => {
    const user = c.get("user");
    const planId = parseInt(c.req.param("id"));
    if (isNaN(planId)) {
        return c.json({ message: "Invalid plan ID" }, 400);
    }
    try {
        // Get the plan
        const plan = await db.query.monthlyPlans.findFirst({
            where: eq(monthlyPlans.id, planId),
        });
        if (!plan) {
            return c.json({ message: "Plan not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, plan.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Update the plan
        const [updatedPlan] = await db
            .update(monthlyPlans)
            .set({
            isClosed: true,
            updatedAt: new Date(),
        })
            .where(eq(monthlyPlans.id, planId))
            .returning();
        return c.json({ plan: updatedPlan });
    }
    catch (error) {
        console.error("Error closing monthly plan:", error);
        return c.json({ message: "Failed to close monthly plan" }, 500);
    }
});
export default monthlyPlanRoutes;
