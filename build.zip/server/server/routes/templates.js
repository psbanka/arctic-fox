import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { db } from "../db";
import { templates, templateTasks, templateTaskAssignments, categories, householdMembers, users, } from "../db/schema";
import { eq, and, inArray } from "drizzle-orm";
import { authenticate } from "../middleware/auth";
const templateRoutes = new Hono();
// Apply authentication to all routes
templateRoutes.use("*", authenticate);
// Create template schema
const createTemplateSchema = z.object({
    name: z.string().min(1, "Template name is required"),
    description: z.string().optional(),
    householdId: z.number().int().positive(),
});
// Create template task schema
const createTemplateTaskSchema = z.object({
    name: z.string().min(1, "Task name is required"),
    description: z.string().optional(),
    categoryId: z.number().int().positive(),
    timesPerMonth: z.number().int().min(1, "Must be at least 1"),
    storyPoints: z.number().int().positive().refine((val) => {
        // Fibonacci sequence check (1, 2, 3, 5, 8, 13, 21, etc.)
        const fibNumbers = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
        return fibNumbers.includes(val);
    }, "Story points must be a Fibonacci number (1, 2, 3, 5, 8, 13, 21, etc.)"),
    assignToAll: z.boolean().default(false),
    assignedUserIds: z.array(z.number().int().positive()).optional(),
});
// Get templates for a household
templateRoutes.get("/household/:householdId", async (c) => {
    const user = c.get("user");
    const householdId = parseInt(c.req.param("householdId"));
    if (isNaN(householdId)) {
        return c.json({ message: "Invalid household ID" }, 400);
    }
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Get templates for this household
        const householdTemplates = await db
            .select()
            .from(templates)
            .where(eq(templates.householdId, householdId));
        return c.json({ templates: householdTemplates });
    }
    catch (error) {
        console.error("Error fetching templates:", error);
        return c.json({ message: "Failed to fetch templates" }, 500);
    }
});
// Create a new template
templateRoutes.post("/", zValidator("json", createTemplateSchema), async (c) => {
    const user = c.get("user");
    const { name, description, householdId } = await c.req.valid("json");
    try {
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, householdId)),
        });
        if (!membership) {
            return c.json({ message: "Household not found or access denied" }, 404);
        }
        // Create the template
        const [newTemplate] = await db
            .insert(templates)
            .values({
            name,
            description,
            householdId,
        })
            .returning();
        return c.json({ template: newTemplate }, 201);
    }
    catch (error) {
        console.error("Error creating template:", error);
        return c.json({ message: "Failed to create template" }, 500);
    }
});
// Get a specific template with its tasks
templateRoutes.get("/:id", async (c) => {
    const user = c.get("user");
    const templateId = parseInt(c.req.param("id"));
    if (isNaN(templateId)) {
        return c.json({ message: "Invalid template ID" }, 400);
    }
    try {
        // Get the template
        const template = await db.query.templates.findFirst({
            where: eq(templates.id, templateId),
        });
        if (!template) {
            return c.json({ message: "Template not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, template.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Get template tasks
        const tasks = await db
            .select({
            id: templateTasks.id,
            name: templateTasks.name,
            description: templateTasks.description,
            categoryId: templateTasks.categoryId,
            categoryName: categories.name,
            timesPerMonth: templateTasks.timesPerMonth,
            storyPoints: templateTasks.storyPoints,
            assignToAll: templateTasks.assignToAll,
            createdAt: templateTasks.createdAt,
            updatedAt: templateTasks.updatedAt,
        })
            .from(templateTasks)
            .leftJoin(categories, eq(templateTasks.categoryId, categories.id))
            .where(eq(templateTasks.templateId, templateId));
        // Get task assignments
        const templateTaskIds = tasks.map((task) => task.id);
        // Only fetch assignments if there are tasks
        let assignmentsByTask = {};
        if (templateTaskIds.length > 0) {
            const assignments = await db
                .select({
                taskId: templateTaskAssignments.templateTaskId,
                userId: users.id,
                firstName: users.firstName,
                lastName: users.lastName,
            })
                .from(templateTaskAssignments)
                .innerJoin(users, eq(templateTaskAssignments.userId, users.id))
                .where(inArray(templateTaskAssignments.templateTaskId, templateTaskIds));
            // Group assignments by task
            assignmentsByTask = assignments.reduce((acc, curr) => {
                if (!acc[curr.taskId]) {
                    acc[curr.taskId] = [];
                }
                acc[curr.taskId].push({
                    userId: curr.userId,
                    firstName: curr.firstName,
                    lastName: curr.lastName,
                });
                return acc;
            }, {});
        }
        // Add assignments to tasks
        const tasksWithAssignments = tasks.map((task) => ({
            ...task,
            assignedUsers: assignmentsByTask[task.id] || [],
        }));
        // Get household categories for reference
        const householdCategories = await db
            .select()
            .from(categories)
            .where(eq(categories.householdId, template.householdId));
        // Get household members for reference
        const householdMembersList = await db
            .select({
            id: users.id,
            firstName: users.firstName,
            lastName: users.lastName,
        })
            .from(users)
            .innerJoin(householdMembers, and(eq(householdMembers.userId, users.id), eq(householdMembers.householdId, template.householdId)));
        return c.json({
            template,
            tasks: tasksWithAssignments,
            categories: householdCategories,
            members: householdMembersList,
        });
    }
    catch (error) {
        console.error("Error fetching template:", error);
        return c.json({ message: "Failed to fetch template details" }, 500);
    }
});
// Add a task to a template
templateRoutes.post("/:id/tasks", zValidator("json", createTemplateTaskSchema), async (c) => {
    const user = c.get("user");
    const templateId = parseInt(c.req.param("id"));
    const { name, description, categoryId, timesPerMonth, storyPoints, assignToAll, assignedUserIds = [], } = await c.req.valid("json");
    if (isNaN(templateId)) {
        return c.json({ message: "Invalid template ID" }, 400);
    }
    try {
        // Get the template
        const template = await db.query.templates.findFirst({
            where: eq(templates.id, templateId),
        });
        if (!template) {
            return c.json({ message: "Template not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, template.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Verify the category belongs to this household
        const category = await db.query.categories.findFirst({
            where: and(eq(categories.id, categoryId), eq(categories.householdId, template.householdId)),
        });
        if (!category) {
            return c.json({ message: "Category not found or doesn't belong to this household" }, 400);
        }
        // Create the template task
        const [newTask] = await db
            .insert(templateTasks)
            .values({
            templateId,
            categoryId,
            name,
            description,
            timesPerMonth,
            storyPoints,
            assignToAll,
        })
            .returning();
        // If not assigned to all, create assignments for specific users
        if (!assignToAll && assignedUserIds.length > 0) {
            // Verify all users are household members
            const householdMemberIds = await db
                .select({ userId: householdMembers.userId })
                .from(householdMembers)
                .where(eq(householdMembers.householdId, template.householdId));
            const validMemberIds = new Set(householdMemberIds.map((m) => m.userId));
            const validAssignees = assignedUserIds.filter((id) => validMemberIds.has(id));
            // Create assignments
            if (validAssignees.length > 0) {
                await db.insert(templateTaskAssignments).values(validAssignees.map((userId) => ({
                    templateTaskId: newTask.id,
                    userId,
                })));
            }
        }
        // Get category info for the response
        const taskWithCategory = {
            ...newTask,
            categoryName: category.name,
        };
        return c.json({ task: taskWithCategory }, 201);
    }
    catch (error) {
        console.error("Error creating template task:", error);
        return c.json({ message: "Failed to create template task" }, 500);
    }
});
// Update a template task
templateRoutes.put("/tasks/:taskId", zValidator("json", createTemplateTaskSchema), async (c) => {
    const user = c.get("user");
    const taskId = parseInt(c.req.param("taskId"));
    const { name, description, categoryId, timesPerMonth, storyPoints, assignToAll, assignedUserIds = [], } = await c.req.valid("json");
    if (isNaN(taskId)) {
        return c.json({ message: "Invalid task ID" }, 400);
    }
    try {
        // Get the task
        const task = await db.query.templateTasks.findFirst({
            where: eq(templateTasks.id, taskId),
        });
        if (!task) {
            return c.json({ message: "Task not found" }, 404);
        }
        // Get the template
        const template = await db.query.templates.findFirst({
            where: eq(templates.id, task.templateId),
        });
        if (!template) {
            return c.json({ message: "Template not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, template.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Verify the category belongs to this household
        const category = await db.query.categories.findFirst({
            where: and(eq(categories.id, categoryId), eq(categories.householdId, template.householdId)),
        });
        if (!category) {
            return c.json({ message: "Category not found or doesn't belong to this household" }, 400);
        }
        // Update the task
        const [updatedTask] = await db
            .update(templateTasks)
            .set({
            name,
            description,
            categoryId,
            timesPerMonth,
            storyPoints,
            assignToAll,
            updatedAt: new Date(),
        })
            .where(eq(templateTasks.id, taskId))
            .returning();
        // Delete existing assignments
        await db
            .delete(templateTaskAssignments)
            .where(eq(templateTaskAssignments.templateTaskId, taskId));
        // If not assigned to all, create new assignments for specific users
        if (!assignToAll && assignedUserIds.length > 0) {
            // Verify all users are household members
            const householdMemberIds = await db
                .select({ userId: householdMembers.userId })
                .from(householdMembers)
                .where(eq(householdMembers.householdId, template.householdId));
            const validMemberIds = new Set(householdMemberIds.map((m) => m.userId));
            const validAssignees = assignedUserIds.filter((id) => validMemberIds.has(id));
            // Create assignments
            if (validAssignees.length > 0) {
                await db.insert(templateTaskAssignments).values(validAssignees.map((userId) => ({
                    templateTaskId: updatedTask.id,
                    userId,
                })));
            }
        }
        return c.json({
            task: {
                ...updatedTask,
                categoryName: category.name,
            },
        });
    }
    catch (error) {
        console.error("Error updating template task:", error);
        return c.json({ message: "Failed to update template task" }, 500);
    }
});
// Delete a template task
templateRoutes.delete("/tasks/:taskId", async (c) => {
    const user = c.get("user");
    const taskId = parseInt(c.req.param("taskId"));
    if (isNaN(taskId)) {
        return c.json({ message: "Invalid task ID" }, 400);
    }
    try {
        // Get the task
        const task = await db.query.templateTasks.findFirst({
            where: eq(templateTasks.id, taskId),
        });
        if (!task) {
            return c.json({ message: "Task not found" }, 404);
        }
        // Get the template
        const template = await db.query.templates.findFirst({
            where: eq(templates.id, task.templateId),
        });
        if (!template) {
            return c.json({ message: "Template not found" }, 404);
        }
        // Verify user is a member of this household
        const membership = await db.query.householdMembers.findFirst({
            where: and(eq(householdMembers.userId, user.id), eq(householdMembers.householdId, template.householdId)),
        });
        if (!membership) {
            return c.json({ message: "Access denied" }, 403);
        }
        // Delete the task (assignments will cascade)
        await db.delete(templateTasks).where(eq(templateTasks.id, taskId));
        return c.json({ message: "Task deleted successfully" });
    }
    catch (error) {
        console.error("Error deleting template task:", error);
        return c.json({ message: "Failed to delete template task" }, 500);
    }
});
export default templateRoutes;
