import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { Pool } from "pg";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
// Get the directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Load environment variables
dotenv.config();
// Database connection configuration
const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
    throw new Error("DATABASE_URL is not defined");
}
// Function to run migrations
async function runMigrations() {
    // Create a PostgreSQL pool
    const pool = new Pool({
        connectionString,
    });
    // Create a Drizzle instance
    const db = drizzle(pool);
    // Set up the migrator
    console.log("Running migrations...");
    try {
        await migrate(db, {
            migrationsFolder: path.join(__dirname, "../../drizzle"),
        });
        console.log("Migrations completed successfully");
    }
    catch (error) {
        console.error("Error running migrations:", error);
        process.exit(1);
    }
    finally {
        await pool.end();
    }
}
// Run migrations
runMigrations();
