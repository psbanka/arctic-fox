// Type mapping functions to convert between database models and API types
export function mapUserModelToUser(model) {
    return {
        id: model.id,
        username: model.username,
        firstName: model.firstName,
        lastName: model.lastName,
        isAdmin: model.isAdmin,
        createdAt: model.createdAt?.toISOString(),
    };
}
export function mapHouseholdModelToHousehold(model) {
    return {
        id: model.id,
        name: model.name,
        createdAt: model.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: model.updatedAt?.toISOString() || new Date().toISOString(),
    };
}
export function mapCategoryModelToCategory(model) {
    return {
        id: model.id,
        name: model.name,
        description: model.description,
        householdId: model.householdId,
        createdAt: model.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: model.updatedAt?.toISOString() || new Date().toISOString(),
    };
}
export function mapTemplateModelToTemplate(model) {
    return {
        id: model.id,
        name: model.name,
        description: model.description,
        householdId: model.householdId,
        isActive: model.isActive,
        createdAt: model.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: model.updatedAt?.toISOString() || new Date().toISOString(),
    };
}
export function mapMonthlyPlanModelToMonthlyPlan(model) {
    return {
        id: model.id,
        householdId: model.householdId,
        month: model.month,
        year: model.year,
        name: model.name,
        isClosed: model.isClosed,
        createdAt: model.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: model.updatedAt?.toISOString() || new Date().toISOString(),
    };
}
export function mapTaskModelToTask(model) {
    return {
        id: model.id,
        name: model.name,
        description: model.description,
        categoryId: model.categoryId,
        storyPoints: model.storyPoints,
        isTemplateTask: model.isTemplateTask,
        isCompleted: model.isCompleted,
        completedAt: model.completedAt?.toISOString() || null,
        completedBy: model.completedBy,
        dueDate: model.dueDate?.toISOString() || null,
        createdAt: model.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: model.updatedAt?.toISOString() || new Date().toISOString(),
    };
}
// Request type conversions for API endpoints
export function createUserRequestToNewUser(request, passwordHash) {
    return {
        username: request.username,
        passwordHash,
        firstName: request.firstName,
        lastName: request.lastName,
        isAdmin: request.isAdmin || false,
    };
}
export function createHouseholdRequestToNewHousehold(request) {
    return {
        name: request.name,
    };
}
export function createCategoryRequestToNewCategory(request) {
    return {
        name: request.name,
        description: request.description || null,
        householdId: request.householdId,
    };
}
export function createTemplateRequestToNewTemplate(request) {
    return {
        name: request.name,
        description: request.description || null,
        householdId: request.householdId,
        isActive: true,
    };
}
export function createMonthlyPlanRequestToNewMonthlyPlan(request) {
    return {
        householdId: request.householdId,
        month: request.month,
        year: request.year,
        name: request.name,
        isClosed: false,
    };
}
