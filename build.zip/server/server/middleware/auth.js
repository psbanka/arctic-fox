import { verifyToken } from "../utils/auth";
// Authentication middleware
export async function authenticate(c, next) {
    try {
        const authHeader = c.req.header("Authorization");
        if (!authHeader) {
            return c.json({ message: "Authentication required" }, 401);
        }
        // Check if the header starts with "Bearer "
        if (!authHeader.startsWith("Bearer ")) {
            return c.json({ message: "Invalid authentication format" }, 401);
        }
        // Extract the token from the header
        const token = authHeader.slice(7);
        // Verify the token
        const user = verifyToken(token);
        if (!user) {
            return c.json({ message: "Invalid or expired token" }, 401);
        }
        // Set the user in the context
        c.set("user", user);
        // Continue to the next middleware or handler
        return await next();
    }
    catch (error) {
        console.error("Authentication error:", error);
        return c.json({ message: "Authentication failed" }, 401);
    }
}
// Admin authorization middleware
export async function requireAdmin(c, next) {
    const user = c.get("user");
    if (!user.isAdmin) {
        return c.json({ message: "Admin access required" }, 403);
    }
    return await next();
}
