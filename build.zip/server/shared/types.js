/**
 * SHARED TYPES
 *
 * This file contains type definitions shared between the frontend and backend.
 * These represent the "contract" or API between client and server.
 */
export {};
